<?php

namespace CYH\Marketing\Plugins;

use CYH\Plugins\PluginBase;

class SalCoreMarketing extends PluginBase
{
    public static function Install()
    {
        //TODO: add plugin dependency check
    }

    public static function Uninstall()
    {
    }
}